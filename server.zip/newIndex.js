const express = require('express');
const app = express();
const http = require('http');
const fs = require('fs');
const bodyParser = require('body-parser');
var cors = require('cors');

app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
const DBUsersPath = 'DB/users.json';
const DBChats = 'DB/Chats.json';
const DBMessages = 'DB/messages.json'



const server = http.createServer(app);
var io = require('socket.io')(server, {
  cors: {
    origin: '*',
  }
});




//////////////////////////////////////////////////////////////////////////////
// const { Server } = require("socket.io");
// const io = new Server(server);


var clientIds = [];
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});


io.on('connection', (socket) => {
  console.log('a user connected');

  clientIds.push(socket.id);
  io.to(socket.id).emit('myConnId', socket.id);

  socket.on('disconnect', (reason) => {
    console.log('user disconnected', reason);
  });

  socket.on('chat message', (msg) => {
    console.log('message: ' + msg.message);
    io.emit('chat message', msg.user + ": " + msg.message);
  });

  socket.on('private-chat', (msg) => {
    console.log('private-chat: ' + msg);
    io.to(clientIds[msg.toUser]).emit('private-chat', { fromUser: msg.fromUser, msg: msg.msg });
  });

  socket.on('new-message', (msg) => {

    if (msg.toChat) {
      msg.msg.chatId=msg.toChat;
      console.log('messageToChannel#' + msg.toChat.toString(),msg.msg);
      io.emit('messageToChannel#' + msg.toChat.toString(), msg.msg);
    }
    else if (msg.toUser) {
      console.log('messageToUser#' + msg.toUser.toString());
      // io.emit('messageToUser#' + msg.toUser.toString(), msg);

      let Messagesf = fs.readFileSync(DBMessages);
      let Messagesj = JSON.parse(Messagesf);
      let betweenUsers = Messagesj.betweenUsers;
      let ch = betweenUsers.find(c => (c.user1 == msg.toUser && c.user2 == msg.fromUser) || (c.user2 == msg.toUser && c.user1 == msg.fromUser));
      if (!ch) { ch = { user1: msg.toUser, user2: msg.fromUser, messages: [] }; betweenUsers.push(ch); }
      let max = (ch.messages.length > 0) ? Math.max(...ch.messages.map(x => x.msgId)) + 1 : 1;
      let m = { msgId: max, msg: msg.msg, from: msg.fromUser, status: 1 };
      ch.messages.push(m);
      io.emit('messageToUser#' + msg.toUser.toString(), m);

      fs.writeFileSync(DBMessages, JSON.stringify(Messagesj));
    }
  });

  socket.on('UserConnectToChannel', (uc) => {
    console.log("UserConnectToChannel", uc.uId);
    let rawdata = fs.readFileSync(DBChats);
    let channels = JSON.parse(rawdata);
    let ch = channels.find(c => c.chatId == uc.chId);
    if (ch) {
      if (!ch.usersIDs.find(x => x == uc.uId)) {
        ch.usersIDs.push(uc.uId);
      }
    }
    fs.writeFileSync(DBChats, JSON.stringify(channels));
  });
  socket.on('UserDisConnectToChannel', (uc) => {
    let rawdata = fs.readFileSync(DBChats);
    let channels = JSON.parse(rawdata);
    let ch = channels.find(c => c.chatId == uc.chId);
    if (ch) {
      let ind = ch.usersIDs.findIndex(x => x == uc.uId);
      ch.usersIDs.splice(ind, 1);
    }
  });

});
/////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////////////////////

app.get('/getUser', function (req, res) {
  let rawdata = fs.readFileSync(DBUsersPath);
  let users = JSON.parse(rawdata);
  let u = users.find(x => x.name == req.query.uName && x.password == req.query.pass)
  if (u) {
    console.log("User found!!");
    res.end(JSON.stringify(u));
  }
  else {
    res.send(JSON.stringify({ error: "user or password are incorrect !!!!" }));
  }

})

app.get('/getUserById', function (req, res) {
  let rawdata = fs.readFileSync(DBUsersPath);
  // res.end(rawdata);
  let users = JSON.parse(rawdata);
  let u = users.find(x => x.id == req.query.uId)
  if (u) {
    console.log("User found!!");
    res.end(JSON.stringify(u));
  }
  else {
    console.log("user not found !!!!");
    res.send("false");
  }

})

app.get('/getAllUsers', function (req, res) {
  console.log('Get All Available Users!!!');
  let rawdata = fs.readFileSync(DBUsersPath);
  res.end(rawdata);

})

app.post('/addUser', function (req, res) {
  // First read existing users.
  let rawdata = fs.readFileSync(DBUsersPath);
  let users = JSON.parse(rawdata);
  var userExists = users.find(x => x.name == req.body.user.name);

  if (!userExists) {
    let maxId;
    if(users && users.length>0){
       maxId= Math.max(...users.map(u => u.id));
    }
    else maxId=0;
    req.body.user.id = maxId + 1;
    req.body.user.isAvailable = true;
    users.push(req.body.user);
    fs.writeFileSync(DBUsersPath, JSON.stringify(users));
    res.end(JSON.stringify({ added: true, user: req.body.user }));
  }
  else {
    res.end(JSON.stringify({ added: false, user: userExists }));//user allready exists
  }
})
///////////////////////////// chats 

app.get('/getChatsChannels', function (req, res) {
  console.log('Get All Chats Channels!!!');
  let rawdata = fs.readFileSync(DBChats);
  res.end(rawdata);

})

app.get('/loadMsgsBetweenUsers', function (req, res) {
  console.log("loadMsgsBetweenUsers");
  let Messagesf = fs.readFileSync(DBMessages);
  let Messagesj = JSON.parse(Messagesf);
  let betweenUsers = Messagesj.betweenUsers;
  let t = req.query.user1;
  let f = req.query.user2;
  let ch = betweenUsers.find(c => (c.user1 == t && c.user2 == f) || (c.user2 == t && c.user1 == f));

  if (ch) {
    res.end(JSON.stringify({ msgs: ch.messages }));
  }
  else res.end(JSON.stringify(null));

})
app.post('/setMsgsAsRead', function (req, res) {
  console.log("setMsgsAsRead", req.body);
  let Messagesf = fs.readFileSync(DBMessages);
  let Messagesj = JSON.parse(Messagesf);
  let betweenUsers = Messagesj.betweenUsers;
  let t = req.body.user1;
  let f = req.body.user2;
  let ch = betweenUsers.find(c => (c.user1 == t && c.user2 == f) || (c.user2 == t && c.user1 == f));
  if (ch) {
    req.body.msgReadList.forEach(msg => {
      let m = ch.messages.find(mm => mm.msgId == msg);
      if (m) m.status = 2;
    })
    fs.writeFileSync(DBMessages, JSON.stringify(Messagesj));
    // let newMsg=ch.messages.filter(x=>msgReadList.includes(x.msgId));
    io.emit('refreshBetweenUsersMsgs#' + f, req.body);
  }


})

//////////////////////////////////////////////////////////////////////////////
// const MongoClient = require('mongodb').MongoClient;
// const assert = require('assert');

// // Connection URL
// const url = 'mongodb://localhost:27017';

// // Database Name
// const dbName = 'myproject';
// const client = new MongoClient(url);
// // Use connect method to connect to the server
// client.connect(function(err) {
//   assert.equal(null, err);
//   console.log('Connected successfully to server');

//   const db = client.db(dbName);

//   client.close();
// });






server.listen(3001, () => {
  console.log('listening on *:3001');
});