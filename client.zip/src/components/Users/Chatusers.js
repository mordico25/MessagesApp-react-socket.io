import React, { Component } from 'react';


class Chatusers extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            users: [],
            chatId: null
        };
    }
    fetchUsers() {
        if (this.props.usersIDs) {
            this.props.usersIDs.forEach(usrId => {
                fetch("http://localhost:3001/getUserById?uId=" + usrId)
                    .then(res => res.json())
                    .then(
                        (result) => {
                            this.setState({
                                users: [...this.state.users, ...[result]]
                            });
                        },
                        // Note: it's important to handle errors here
                        // instead of a catch() block so that we don't swallow
                        // exceptions from actual bugs in components.
                        (error) => {
                            this.setState({
                                isLoaded: true,
                                error
                            });
                        }
                    )
            });
        }

    }
    componentDidMount() {
        this.fetchUsers();
    }


    componentDidUpdate(prevProps) {
        if ((prevProps && !prevProps.chatId && this.props.chatId) || prevProps.chatId !== this.props.chatId) {
            this.setState({
                users: [], chatId: this.props.chatId
            });
            this.fetchUsers();
        }

    }

    render() {
        const { users } = this.state;
        return (
            <div>
                <h4>Active users on the chat</h4>

                <ol>
                    {users?.map(user => (
                        <li key={user.id}>
                            {user.name}
                        </li>
                    ))}
                </ol>
            </div>
        );
    }
}


export default Chatusers;