import React, { Component } from 'react';
import Chatusers from '../Users/Chatusers'
import socketClient from "socket.io-client";
import './CurrentChat.css';

class CurrentChat extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            chat: props.chat
            , user: props.user
            , currentUser: props.currentUser
            , messages: []
            , myConnId: ""
        };
        this.socket = socketClient(this.props.SERVER);
        this.sendBtnClick = this.sendBtnClick.bind(this);
        this.loadMsgsBetweenUsers = this.loadMsgsBetweenUsers.bind(this);
    }
    componentWillUnmount() {
        console.log("close connection");
        this.socket.close();
    }
    componentDidMount() {

        var componentRef = this;

        this.socket.on('myConnId', function (msg) {
            console.log("connected to socket!!");
            componentRef.setState({ myConnId: msg });
        });


        // if (this.props.chat) {
        //     this.socket.on('messageToChannel#' + this.props.chat.chatId, function (msg) {
        //         if (componentRef.props.chat && componentRef.props.chat.chatId == msg.chatId) {
        //             componentRef.setState({ messages: [...componentRef.state.messages, ...[msg]] });
        //         }
        //     });
        // }

        if (this.props.user) {
            this.registerToUser();
        }

        this.scrollToBottom();
    }

    sendBtnClick() {
        var input = document.getElementById('input');
        if (input.value) {
            var now = new Date();
            var strDate = 'HH:mm:ss'
                .replace('HH', now.getHours())
                .replace('mm', now.getMinutes())
                .replace('ss', now.getSeconds());

            let newMsg = {
                toChat: this.props.chat ? this.props.chat.chatId : null
                , toUser: this.props.user ? this.props.user.id : null
                , fromUser: this.props.currentUser.id
                , msg: {
                    msg: input.value
                    , sendingUser: this.props.currentUser.id
                    , date: strDate
                }
            };
            this.socket.emit('new-message', newMsg);
            if (this.props.user) {
                let max;
                if (this.state.messages && this.state.messages.length > 0) {
                    max = Math.max(...this.state.messages.map(m => m.msgId));
                }
                else max = 0;
                let msg = { msgId: max + 1, msg: newMsg.msg, from: newMsg.fromUser, status: 1 }
                console.log("emit('new-message'", msg)
                this.setState({ messages: [...this.state.messages, ...[msg]] });
            }
            else if(this.props.chat){
                newMsg.msg.chatId=this.props.chat.chatId;
                this.setState({ messages: [...this.state.messages, ...[newMsg.msg]] });
            }

            input.value = "";
        }
    }
    componentDidUpdate(prevProps) {
        if (prevProps) {
            // console.log('.off(messageToChannel#' + prevProps.chat?.chatId);         
            // console.log('.off(messageToUser#' + prevProps.currentUser?.id);

            this.socket.off('messageToChannel#' + prevProps.chat?.chatId, null);
            this.socket.off('messageToUser#' + prevProps.currentUser?.id, null);
            this.socket.off('refreshBetweenUsersMsgs');
           
            // this.socket.removeAllListeners('messageToUser#' + prevProps.currentUser?.id);
            // this.socket.removeAllListeners('refreshBetweenUsersMsgs');
        }
        if (!prevProps.user && !prevProps.chat) { //רישום בפעם הראשונה

            if (this.props.user) {
                this.setState({
                    user: this.props.user, messages: []
                });
                this.registerToUser();
            }
            if (this.props.chat) {
                this.setState({
                    chat: this.props.chat, messages: []
                });
                this.registerToChannel();
            }
        }
        else if (prevProps.chat && !this.props.chat && this.props.user) {//מקודם היה רישום לצ'אט ועכשיו רישום ליוזר
            // this.socket.removeAllListeners('messageToChannel#' + prevProps.chat?.chatId);
            this.registerToUser();
            this.setState({ messages: [], user: this.props.user, chat: null });
        }
        else if (prevProps.user && !this.props.user && this.props.chat) {//מקודם היה רישום ליוזר ועכשיו רישום לצ'אט

            // this.socket.removeAllListeners('messageToUser#' + prevProps.currentUser?.id);
            // this.socket.removeAllListeners('refreshBetweenUsersMsgs');
            // this.socket.off('refreshBetweenUsersMsgs', null);
           
            this.registerToChannel();
            this.setState({ messages: [], chat: this.props.chat, user: null });
        }
        else if (prevProps.chat && (prevProps.chat.chatId !== this.props.chat.chatId)) {//שינוי צ'אט
            // this.socket.removeAllListeners('messageToChannel#' + prevProps.chat?.chatId);
            this.setState({
                chat: this.props.chat, messages: []
            });
            if (this.props.chat) {
                // console.log('.off(messageToChannel#' + prevProps.chat?.chatId);
                // this.socket.off('messageToChannel#' + prevProps.chat?.chatId, null);
                this.registerToChannel();
            }
        }
        else if (prevProps.user && (prevProps.user.id !== this.props.user.id)) {//שינוי יוזר
            this.socket.off('messageToUser#' + prevProps.currentUser?.id, null);
            this.socket.off('refreshBetweenUsersMsgs');
            this.setState({
                user: this.props.user, messages: []
            });
            if (this.props.user) {
                this.registerToUser();
            }
        }

        this.scrollToBottom();
    }

    registerToChannel() {
        var componentRef = this;
        console.log('.on(messageToChannel#' + this.props.chat.chatId);
        this.socket.on('messageToChannel#' + this.props.chat.chatId, function (msg) {
            if (componentRef.props.chat 
                && componentRef.props.chat.chatId == msg.chatId 
                && msg.sendingUser!=componentRef.props.currentUser.id
                && !componentRef.state.messages.find(x=>x.msg==msg.msg && x.date==msg.date)) {
                componentRef.setState({ messages: [...componentRef.state.messages, ...[msg]] });
            }
        });
        this.socket.emit('UserConnectToChannel'
            , {
                chId: this.props.chat.chatId
                , uId: this.props.currentUser.id
            }
        );

    }
    registerToUser() {
        var componentRef = this;
        console.log('.on(messageToUser#' + this.props.currentUser.id);
        this.socket.on('messageToUser#' + this.props.currentUser.id, function (msg) {
            console.log("messageToUser recived!!!!!!!!!!")
            if (componentRef.props.user && componentRef.props.user.id == msg.from) {
                if (!componentRef.state.messages.find(m => m.msgId == msg.msgId)) {
                    componentRef.setState({ messages: [...componentRef.state.messages, ...[msg]] });
                }

                const requestOptions = {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        user1: componentRef.props.currentUser.id,
                        user2: componentRef.props.user.id,
                        msgReadList: [msg.msgId]
                    })
                };
                fetch('http://localhost:3001/setMsgsAsRead', requestOptions);
            }
        });
        this.socket.on('refreshBetweenUsersMsgs#' + this.props.currentUser.id, function (req) {
            console.log("refreshBetweenUsersMsgs recived!!!!!!!!!!", req)
            if (componentRef.props.user && componentRef.props.user.id == req.user1) {
                componentRef.state.messages.forEach(m => {
                    console.log(m.msgId);
                    if (req.msgReadList.includes(m.msgId)) {
                        m.status = 2;
                    }
                })
                console.log("refreshBetweenUsersMsgs recived!!!!!!!!!!", req.msgReadList)
                componentRef.setState({ messages: componentRef.state.messages });
            }

        });
        this.loadMsgsBetweenUsers()
    }

    loadMsgsBetweenUsers() {
        console.log("loadMsgsBetweenUsers!!!!!!!!!!", this.props.user.id)
        fetch(
            "http://localhost:3001/loadMsgsBetweenUsers?user1=" + this.props.currentUser.id + "&user2=" + this.props.user.id
            , { method: 'GET' })
            .then(res => res.json())
            .then(
                (result) => {
                    if (result) {
                        this.setState({
                            messages: result.msgs
                        });
                        if (result.msgs.length > 0) {
                            let msgReadList = result.msgs.filter(x => x.status == 1 && x.from != this.props.currentUser.id).map(m => m.msgId);
                            if (msgReadList && msgReadList.length > 0) {
                                let requestOptions = {
                                    method: 'POST',
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify({
                                        user1: this.props.currentUser.id,
                                        user2: this.props.user.id,
                                        msgReadList: msgReadList
                                    })
                                };
                                fetch('http://localhost:3001/setMsgsAsRead', requestOptions);
                            }
                        }
                    }
                }
            )
    }
    scrollToBottom = () => {
        this.messagesEnd.scrollIntoView({ behavior: "smooth" });
    }

    render() {
        const { chat, user, messages } = this.state;
        if (!chat && !user) return null;
        if (chat) {
            return (
                <div className="divchat">
                    <div>
                        <h4>{"Chat on the " + chat.ChatName + " channel"}</h4>
                    </div>
                    <div style={{ 'width': '30%', 'display': 'inline-block', 'border': 'azure 2px solid' }}>
                        <Chatusers usersIDs={chat.usersIDs} chatId={chat.chatId} />
                    </div>
                    <div style={{ 'width': '65%', 'display': 'inline-block', 'border': 'azure 2px solid' }}>

                        <ul style={{ 'height': '70vh', 'overflow-y': 'auto' }}>
                            {messages.map(msg => (<li key={msg.date} className={msg.sendingUser == this.props.currentUser.id ? "myMsg liChat" : "notMyMsg liChat"}>  {msg.msg} </li>))}
                            <li style={{ visibility: "hidden" }} ref={(el) => { this.messagesEnd = el; }}> </li>
                        </ul>

                        <div>
                            <input id="input" autoComplete="off" className="inptMsg" />
                            <button type="button" id="privateMsgBtn" className="btnSend" onClick={this.sendBtnClick}>SEND</button>
                        </div>

                    </div>
                </div>
            );
        }

        if (user) {
            return (
                <div className="divchat">
                    <div>
                        <h4>{"Chat with " + user.name}</h4>
                    </div>

                    <div style={{ 'width': '85%', 'display': 'inline-block', 'border': 'azure 2px solid' }}>

                        <ul style={{ 'height': '70vh', 'overflow-y': 'auto' }}>
                            {messages.map(msg => (
                                <li key={msg.msgId}
                                    className={msg.msg.sendingUser == this.props.currentUser.id ? "myMsg" : "notMyMsg"}>
                                    {msg.msg.msg + "     "}
                                    {msg.msg.sendingUser != this.props.currentUser.id ? "" :
                                        (
                                            (msg.msg.sendingUser == this.props.currentUser.id) && msg.status == 1 ? <span style={{ "color": "#75a3a3" }}>V</span> :
                                                ((msg.msg.sendingUser == this.props.currentUser.id) && msg.status == 2 ? <span style={{ "color": "#0af5f5" }}>V V</span> : "")
                                        )
                                    }
                                </li>))}
                            <li style={{ visibility: "hidden" }} ref={(el) => { this.messagesEnd = el; }}> </li>
                        </ul>

                        <div>
                            <input id="input" autoComplete="off" className="inptMsg" />
                            <button type="button" id="privateMsgBtn" className="btnSend" onClick={this.sendBtnClick}>SEND</button>
                        </div>

                    </div>
                </div>
            );

        }
    }

}

export default CurrentChat;