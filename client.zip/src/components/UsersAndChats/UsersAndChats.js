import React, { Component } from 'react';
import './UsersAndChats.css'

class UsersAndChats extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            error: null,
            isLoaded: false,
            users: [],
            chats: []
        };
    }

    componentDidMount() {
        fetch("http://localhost:3001/getAllUsers")
            .then(res => res.json())
            .then(
                (result) => {
                    this.setState({
                        isLoaded: true,
                        users: result
                    });
                },
                (error) => {
                    this.setState({
                        isLoaded: true,
                        error
                    });
                }
            )

        fetch("http://localhost:3001/getChatsChannels")
            .then(res => res.json())
            .then(
                (result) => {
                    console.log(result);
                    this.setState({
                        isLoaded: true,
                        chats: result
                    });
                },
                // Note: it's important to handle errors here
                // instead of a catch() block so that we don't swallow
                // exceptions from actual bugs in components.
                (error) => {
                    this.setState({
                        isLoaded: true,
                        error
                    });
                }
            )
    }


    activateChat(chat){
        this.props.onActivateChat(chat);
    }
    activateUser(user){
        this.props.onActivateUser(user);
    }
    render() {
        const { error, isLoaded, users ,chats} = this.state;
        if (error) {
            return <div>Error: {error.message}</div>;
        } else if (!isLoaded) {
            return <div>Loading...</div>;
        } else {
            return (
                <div className="ucDiv">
                    <h4>Available users And Channels</h4>
                    <div>
                        <h5>Users</h5>
                        <ul>
                            {users.filter(x=>x.id!=this.props.currentUser.id).map(user => (
                                <li key={user.id}  onClick={() => this.activateUser(user)} className="chat-option">
                                    {user.isAvailable=="true" ? <span style={{'border-radius':'25px','background-color':'greenyellow'}}>ON</span> : null} 
                                    <span className="">{user.name}</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                    <div>
                        <h5>Chats Channels</h5>
                        <ul>
                            {chats.map(chat => (
                                <li key={chat.chatId}  onClick={() => this.activateChat(chat)} className="chat-option">
                                   <span className="">{chat.ChatName +" ("+chat.usersIDs?.length+")"}</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
            );
        }
    }
}

export default UsersAndChats;
