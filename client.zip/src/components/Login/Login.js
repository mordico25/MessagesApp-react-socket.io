import React, { Component } from 'react';
import './Login.css';
class Login extends React.Component {
    uName = "";
    uPass = "";
    constructor(props) {
        super(props);
        this.state = {
            uName: "",
            uPass: "",
            error: "",
            registerOrLogin: "login"
        };

        this.onLoginClick = this.onLoginClick.bind(this);
        this.onRegisterClick = this.onRegisterClick.bind(this);
    }
    setUName(val) {
        this.uName = val;
    }
    setUPass(val) {
        this.uPass = val;
    }

    componentDidMount() {
    }
    onRegisterClick() {

        const requestOptions = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user: { name: this.uName, password: this.uPass } })
        };
        fetch('http://localhost:3001/addUser', requestOptions)
            .then(response => response.json())
            .then(newUser => {newUser.added==true? this.props.onLogin(newUser.user)
                             : this.setState({ error: "user allredy Exists !" });}
            );
    }
    setTab(val) {
        this.setState({ registerOrLogin: val });
    }
    onLoginClick() {

        if (this.uName && this.uPass) {
            fetch("http://localhost:3001/getUser?uName=" + this.uName + "&pass=" + this.uPass)
                .then(res => res.json())
                .then(
                    (result) => {
                        if(!result.error) this.props.onLogin(result);
                        else this.setState({ error: result.error })
                    },

                    (error) => {
                        console.error("get user ERROR: " + error.toString());
                        this.setState({ error: "user name or password are incorrect!" })
                    }
                )

        }

    }

    render() {

        return (
            <div className="Login">

                <div style={{ "border-bottom": "1px solid white" }}>
                    <button type="button"className='tabBtn' className={ this.state.registerOrLogin == "login" ? 'active' : ""} onClick={() => this.setTab("login")}>Login</button>
                    <button type="button"className='tabBtn' className={'tabBtn', this.state.registerOrLogin == "register" ? 'active' : ""} onClick={() => this.setTab("register")}>Register</button>

                </div>

                { this.state.registerOrLogin == "login" ?
                    <div >

                        <span className="spn">User Name</span><input type="text" id="uName" onChange={event => this.setUName(event.target.value)} ></input>
                        <br />
                        <span className="spn">Password</span><input type="text" id="uPass" onChange={event => this.setUPass(event.target.value)} ></input>
                        <br />
                        <br />
                        {this.state.error ? <span style={{ 'color': 'red' }}>{this.state.error}</span> : null}
                        <button className="btnlogin" type="button" onClick={this.onLoginClick}>Login</button>
                    </div>
                    :
                    <div>

                        <span className="spn">User Name</span><input type="text" id="uName" onChange={event => this.setUName(event.target.value)} ></input>
                        <br />
                        <span className="spn">Password</span><input type="text" id="uPass" onChange={event => this.setUPass(event.target.value)} ></input>
                        <br />
                        <br />
                        {this.state.error ? <span style={{ 'color': 'red' }}>{this.state.error}</span> : null}
                        <br/>
                        <button className="btnlogin" type="button" onClick={this.onRegisterClick}>Register</button>
                    </div >
                }

            </div>
        );
    }
}

export default Login;