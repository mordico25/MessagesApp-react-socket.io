import logo from './logo.svg';
import './App.css';
import UsersAndChats from './components/UsersAndChats/UsersAndChats'
import CurrentChat from './components/CurrentChat/CurrentChat';
import Login from './components/Login/Login';
import React, { Component } from 'react';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      isLoaded: false,
      users: [],
      chats: [],
      ActivatedChat: null,
      ActivatedUser: null,
      currentUser:null
    };
    this.users = [
      { name: "aaaa", id: 1, isAvailable: true }
      , { name: "bbbbb", id: 2, isAvailable: true }
      , { name: "ccccc", id: 3, isAvailable: false }
    ];
    this.SERVER = "http://localhost:3001";
    
  }

  setActivatedChat = (chat) => {
    this.setState({ ActivatedChat: chat, ActivatedUser: null });
  };
  setActivatedUser = (user) => {
    this.setState({ ActivatedChat: null, ActivatedUser: user });
  };

  setCurrenUser =(currentUser) =>{
    this.setState({ currentUser: currentUser });
  }


  render() {

    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" style={{ 'width': '3vw','float':'left' }} />
          <h3 >Wellcome to MC Chat</h3>
          <h5  style={{ 'margin': '0'}}>{this.state.currentUser? "connected as "+this.state.currentUser.name :""}</h5>
        </header>

        {
          this.state.currentUser ?
            <div dir="rtl">
              <div className="usersAndChats">

                <UsersAndChats onActivateChat={this.setActivatedChat} onActivateUser={this.setActivatedUser} currentUser={this.state.currentUser} />

              </div>
              <div style={{ 'width': '68vw', 'display': 'inline-block' ,'vertical-align': 'top'}}>
                {
                  (this.state.ActivatedChat || this.state.ActivatedUser) ?
                    <CurrentChat chat={this.state.ActivatedChat} user={this.state.ActivatedUser} currentUser={this.state.currentUser} SERVER={this.SERVER} />
                    : null
                }
              </div>
            </div>
            :

            <Login onLogin={this.setCurrenUser}></Login>

        }

      </div>
    );
  }
}

export default App;
